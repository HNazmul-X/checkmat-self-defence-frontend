export const apiBase = ``
export const userAuthToken = `3ca24d1f52660d7d7255c259c14fe3a74e5d5c552b39221b36a76`;