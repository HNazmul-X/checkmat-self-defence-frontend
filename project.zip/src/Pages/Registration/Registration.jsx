import React from 'react';

const Registration = () => {
    return (
        <div className='text-4xl'>
            Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ea, saepe.
        </div>
    );
};

export default Registration;