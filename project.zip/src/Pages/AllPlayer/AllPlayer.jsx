import React from 'react';

const AllPlayer = () => {
    return (
        <div>
            <h1 className='text-5xl'>This is All Player page</h1>
        </div>
    );
};

export default AllPlayer;